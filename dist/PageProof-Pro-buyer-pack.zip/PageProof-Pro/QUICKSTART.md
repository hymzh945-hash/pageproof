# PageProof Pro — quickstart

PageProof checks a PDF before it leaves your desk: mixed page sizes, a landscape page in a
portrait document, text inside the trim margin, scanned pages with no text layer, images
placed at print resolution far too low, 5pt type, five typefaces on one page, blank pages,
missing metadata.

## 1. Install

```bash
pip install pageproof
```

Python 3.9+. Nothing else installs, nothing calls home.

## 2. Activate Pro

Put the licence file we emailed you at either:

```bash
~/pageproof-license.json
# or
~/.pageproof/license.json
```

Or point at it explicitly:

```bash
export PAGEPROOF_LICENSE=/path/to/pageproof-license.json
```

Check it:

```bash
pageproof license
# Pro license · you@example.com · expires 2027-11-18
```

Verification is local (Ed25519 against a public key inside the package), so it works on a
machine with no network.

## 3. Audit a file

```bash
pageproof audit -i brochure.pdf
```

Terminal output: score, verdict, per-check counts, page count and page-1 geometry.

## 4. Get the report and the checklist (Pro)

```bash
pageproof audit -i brochure.pdf --report prepress.html --csv findings.csv
```

- `prepress.html` — self-contained, dark, one file. Send it to the designer or the printer.
- `findings.csv` — severity, check, page, object, detail. One row per finding.

## 5. Learn it on a broken file

```bash
pageproof demo -o pageproof-demo
```

Writes a bundled five-page PDF with every defect the checks look for, audits it, and writes
`pageproof-report.html`. Works offline; needs no extra install.

## What the score means

`100 * exp(-penalty / 120)`, penalty is severity-weighted and capped per check so one noisy
check cannot flatten the score.

- **85+** — print-ready.
- **65–84** — fixable before it ships.
- **below 65** — will bounce at the printer.

## Checks included

| Check | Severity |
|---|---|
| mixed_page_size — a page geometry that differs from page 1 | high |
| mixed_orientation — landscape page in a portrait document | medium |
| no_text_layer — page is pictures only, needs OCR | high |
| blank_page — no text, no images | medium |
| text_outside_page — text crosses the page edge | high |
| text_in_trim — text inside the 0.25in print safety margin | medium |
| tiny_text — characters under 6pt | medium |
| low_dpi_image — image under 150 DPI at its placed size | medium |
| font_sprawl — more than four typefaces on one page | medium |
| single_font_layer — every page uses one typeface set | low |
| missing_metadata / empty_metadata | low |

## Limits, stated plainly

- Text-layer detection is a character count, not OCR. A page with a picture plus a few
  characters reads as text; open the flagged page before trusting it.
- Effective DPI comes from the embedded pixel size against the placed size. Vector art,
  masks and colour separations are not scored.
- Trim is measured from the page edge. If your printer supplies a TrimBox, subtract your
  real margin before reading the numbers.
- Overprint, bleed marks and spot colours remain a job for a real preflight tool.

## Support

Reply to the receipt email. Send the PDF if you can — we do not redistribute client files.
